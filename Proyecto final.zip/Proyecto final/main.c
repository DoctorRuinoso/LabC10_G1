#include <stdio.h>
#include "lib/core.h"
#include "lib/profesor.h"
#include "lib/administrador.h"


int main() {

    unsigned exit_token=1;
    unsigned logged_user;
    core_data_recovery();
    while (exit_token==1)
    {
        if (core_config_options_menu()== 1)
            alta_usuario();
        else{logged_user=core_login();}

        if (usuario[logged_user].perfil=="a"){
            menu_administrador(logged_user);
        }
        if (usuario[logged_user].perfil=="p"){
            perfil_profesor_menu_general(logged_user);
        }
        printf("Deseas hacer alguna operacion mas?\n1)Si\t 2)No\n");
        scanf("%d",&exit_token);

    }
    core_end_execution();

    return 0;
}